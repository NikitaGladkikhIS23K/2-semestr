def main():

    M = int(input("Введите количество строк: "))
    
    spaced_words = []

    for i in range(M):

        word = input(f"Введите слово {i + 1}: ")
        
        spaced_word = ' '.join(word)
        
        spaced_words.append(spaced_word)

    for i in range(M):
        print(f"Слово {i + 1} в разрядке: {spaced_words[i]}")

if __name__ == "__main__":
    main()
