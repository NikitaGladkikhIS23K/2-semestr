def camel(st):

    result = ''
    upper = True
    for char in st:
        if char.isalpha():
            if upper:
                result += char.upper()
            else:
                result += char.lower()
            upper = not upper
        else:
            result += char
    return result

print(camel("hello world"))
print(camel("CamelCase"))
print(camel("123 abc"))
print(camel("Hello, world!"))
print(camel(""))
