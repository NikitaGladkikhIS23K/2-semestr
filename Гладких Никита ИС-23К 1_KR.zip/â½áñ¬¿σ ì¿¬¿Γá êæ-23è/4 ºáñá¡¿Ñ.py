def main():
    sum_odd_index = 0
    product_even_index = 1
    count_addends = 0
    count_multipliers = 0

    index = 0

    while True:
        number = input("Введите число (или 55555 для завершения): ")
        
        if number == "55555":
            break

        try:
            number = int(number)
        except ValueError:
            print("Пожалуйста, введите корректное целое число.")
            continue

        if index % 2 == 0:
            product_even_index *= number
            count_multipliers += 1
        else:
            sum_odd_index += number
            count_addends += 1

        index += 1

    print(f"Сумма чисел с нечётными индексами: {sum_odd_index}")
    print(f"Произведение чисел с чётными индексами: {product_even_index}")
    print(f"Количество слагаемых: {count_addends}")
    print(f"Количество сомножителей: {count_multipliers}")

if __name__ == "__main__":
    main()
