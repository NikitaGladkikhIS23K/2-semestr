import psycopg2
from psycopg2 import Error

try:
    connection = psycopg2.connect(
        user="postgres",
        password="1111",
        host="127.0.0.1",
        port="5432",
        database="postgres_db"
    )
    cursor = connection.cursor()
    cursor.callproc("filter_by_price", [999])
    
    print("Запись с ценой меньше или равной 999")
    for row in cursor.fetchall():
        print("Id =", row[0])
        print("Model =", row[1])
        print("Price =", row[2])

except (Exception, Error) as error:
    print("Ошибка при работе с PostgreSQL", error)
finally:
    if connection:
        cursor.close()
        connection.close()
        print("Соединение с PostgreSQL закрыто")
        