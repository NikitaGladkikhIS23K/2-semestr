class Vector3D:

    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z

    def __add__(self, other):
        if isinstance(other, Vector3D):
            return Vector3D(self.x + other.x, self.y + other.y, self.z + other.z)
        
    def __sub__(self, other):
        if isinstance(other, Vector3D):
            return Vector3D(self.x - other.x, self.y - other.y, self.z - other.z)
        
    def __mul__(self, other):
        if isinstance(other, Vector3D):
            return self.x * other.x + self.y * other.y + self.z * other.z
        elif isinstance(other, (int, float)):
            return Vector3D(self.x * other, self.y * other, self.z * other)
        
    def __rmul__(self, other):
        return self.__mul__(other)
    
    def __repr__(self):
        return f"Vector3D({self.x}, {self.y}, {self.z})"
    
    def __eq__(self, other):
        if isinstance(other, Vector3D):
            return self.x == other.x and self.y == other.y and self.z == other.z
        return False
    
if __name__ == "__main__":
    v1 = Vector3D(1, 2, 3)
    v2 = Vector3D(4, 5, 6)
    print("Сложение векторов:")
    print(f"{v1} + {v2} = {v1 + v2}")
    print()
    print("Вычитание векторов:")
    print(f"{v1} - {v2} = {v1 - v2}")
    print()
    print("Скалярное произведение:")
    print(f"{v1} * {v2} = {v1 * v2}")
    print()
    print("Умножение на скаляр:")
    scalar = 2
    print(f"{v1} * {scalar} = {v1 * scalar}")
    print(f"{scalar} * {v1} = {scalar * v1}")
    print()
    print("Проверка равенства:")
    v3 = Vector3D(1, 2, 3)
    print(f"{v1} == {v3}: {v1 == v3}")
    print(f"{v1} == {v2}: {v1 == v2}")
    