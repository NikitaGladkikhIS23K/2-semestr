class AirCastle:
    def __init__(self, height, clouds_count, color):
        self.height = max(0, height)
        self.clouds_count = clouds_count
        self.color = color
    def change_height(self, value):
        """Изменяет высоту на value (не может быть меньше 0)"""
        self.height = max(0, self.height + value)
    def __add__(self, n):
        """Добавляет n облаков и увеличивает высоту на n // 5"""
        new_clouds = self.clouds_count + n
        new_height = self.height + (n // 5)
        return AirCastle(new_height, new_clouds, self.color)
    def __call__(self, transparency):
        """Рассчитывает видимость замка по формуле: (высота // прозрачность) * облака"""
        if transparency == 0:
            return 0
        return (self.height // transparency) * self.clouds_count
    def __str__(self):
        """Строковое представление замка"""
        return f"The AirCastle at an altitude of {self.height} meters is {self.color} with {self.clouds_count} clouds"
    
    def __eq__(self, other):
        if not isinstance(other, AirCastle):
            return False
        return (self.clouds_count, self.height, self.color) == (other.clouds_count, other.height, other.color)
    def __lt__(self, other):
        if not isinstance(other, AirCastle):
            return NotImplemented
        return (self.clouds_count, self.height, self.color) < (other.clouds_count, other.height, other.color)
    def __le__(self, other):
        return self < other or self == other
    def __gt__(self, other):
        return not (self <= other)
    def __ge__(self, other):
        return not (self < other)
    def __ne__(self, other):
        return not (self == other)

if __name__ == "__main__":
    castle1 = AirCastle(100, 50, "blue")
    castle2 = AirCastle(120, 40, "red")

    print(castle1)
    castle1.change_height(-20)
    print(castle1)

    castle3 = castle1 + 10
    print(castle3)

    visibility = castle3(5)
    print(f"Видимость замка: {visibility}")

    print(castle1 > castle2)
    print(castle1 < castle2)
    print(castle1 == AirCastle(80, 50, "blue"))
