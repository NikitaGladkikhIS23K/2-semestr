class Talking:
    def __init__(self, name):
        self.name = name
        self.answer_yes = True

    def to_answer(self):
        if self.answer_yes:
            response = "moore-moore"
        else:
            response = "meow-meow"
        self.answer_yes = not self.answer_yes
        return response
if __name__ == "__main__":
    kuzia = Talking("Кузя")

    print(f"{kuzia.name} говорит: {kuzia.to_answer()}")
    print(f"{kuzia.name} говорит: {kuzia.to_answer()}")
    print(f"{kuzia.name} говорит: {kuzia.to_answer()}")
    print(f"{kuzia.name} говорит: {kuzia.to_answer()}")
    