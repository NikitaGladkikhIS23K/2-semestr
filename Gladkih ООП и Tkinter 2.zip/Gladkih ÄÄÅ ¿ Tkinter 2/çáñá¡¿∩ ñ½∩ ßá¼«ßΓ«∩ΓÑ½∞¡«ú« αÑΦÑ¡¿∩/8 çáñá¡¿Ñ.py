class Snow:
    def __init__(self, count):
        self.count = count

    def __add__(self, n):
        return Snow(self.count + n)

    def __sub__(self, n):
        return Snow(self.count - n)

    def __mul__(self, n):
        return Snow(self.count * n)

    def __truediv__(self, n):
        return Snow(self.count // n)

    def makeSnow(self, snowflakes_per_row):
        if snowflakes_per_row <= 0:
            return ""
        
        full_rows = self.count // snowflakes_per_row
        remaining_snowflakes = self.count % snowflakes_per_row
        
        rows = ["*" * snowflakes_per_row for _ in range(full_rows)]
        if remaining_snowflakes > 0:
            rows.append("*" * remaining_snowflakes)
        
        return "\n".join(rows)

    def __str__(self):
        return f"Snow({self.count})"
if __name__ == "__main__":
    snow = Snow(12)

    snow = snow + 5
    print(snow)
    snow = snow - 3
    print(snow)
    snow = snow * 2
    print(snow)
    snow = snow / 3
    print(snow)

    print("\nСнежинки в 3 ряда:")
    print(snow.makeSnow(3))

    print("\nСнежинки в 4 ряда:")
    print(snow.makeSnow(4))

    print("\nСнежинки в 5 рядов:")
    print(snow.makeSnow(5))
    