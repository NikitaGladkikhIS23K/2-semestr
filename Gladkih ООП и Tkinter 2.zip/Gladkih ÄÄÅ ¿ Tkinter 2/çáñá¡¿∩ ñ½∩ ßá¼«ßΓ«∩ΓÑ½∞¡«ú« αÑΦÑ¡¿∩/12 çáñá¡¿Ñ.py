class BeeElephant:
    def __init__(self, bee_part, elephant_part):
        self.bee = min(max(0, bee_part), 100)
        self.elephant = min(max(0, elephant_part), 100)
    def fly(self):
        return self.bee >= self.elephant
    def trumpet(self):
        return "tu-tu-doo-doo!" if self.elephant >= self.bee else "wzzzzz"
    def eat(self, meal, value):
        if meal == 'nectar':
            self.elephant = max(0, self.elephant - value)
            self.bee = min(100, self.bee + value)
        elif meal == 'grass':
            self.bee = max(0, self.bee - value)
            self.elephant = min(100, self.elephant + value)
    def get_parts(self):
        return (self.bee, self.elephant)
print("Пример 1:")
be = BeeElephant(3, 2)
print(be.fly())
print(be.trumpet())
be.eat('grass', 4)
print(be.get_parts())
print("\nПример 2:")
be = BeeElephant(13, 87)
print(be.fly())
print(be.trumpet())
be.eat('nectar', 90)
print(be.trumpet())
print(be.get_parts())
