class Human:
    default_name = "Виктория Сикрет"
    default_age = 18

    def __init__(self, name=default_name, age=default_age):
        self.name = name
        self.age = age
        self.__money = 40000
        self.__house = None

    def info(self):
        print(f"Имя: {self.name}")
        print(f"Возраст: {self.age}")
        print(f"Деньги: {self.__money}")
        print(f"Дом: {self.__house}")

    @staticmethod
    def default_info():
        print(f"Default name: {Human.default_name}")
        print(f"Default age: {Human.default_age}")

    def __make_deal(self, house, price):
        self.__money -= price
        self.__house = house

    def earn_money(self, amount):
        self.__money += amount
        print(f"Заработано {amount}. Текущий баланс: {self.__money}")

    def buy_house(self, house, discount):
        final_price = house.final_price(discount)
        if self.__money >= final_price:
            self.__make_deal(house, final_price)

            print(f"Дом куплен за {final_price}!")
        else:
            print(f"Недостаточно денег для покупки дома. Нужно {final_price}, а есть {self.__money}")

class House:
    def __init__(self, area, price):
        self._area = area
        self._price = price
    def final_price(self, discount):
        return self._price * (100 - discount) / 100
    
class SmallHouse(House):
    def __init__(self, price):
        super().__init__(40, price)
if __name__ == "__main__":
    Human.default_info()
    print()
    person = Human("Никита", 18)
    print(" Информация о человеке:")
    person.info()
    print()
    small_house = SmallHouse(30000)
    print("Попытка купить дом без денег:")
    person.buy_house(small_house, 10)
    print()
    print("Воркаем:")
    person.earn_money(40000)
    print()
    print("7. Попытка купить дом после арбитража:")
    person.buy_house(small_house, 10)
    print()
    print("Информация о человеке после покупки кладовки в Москве:")
    person.info()