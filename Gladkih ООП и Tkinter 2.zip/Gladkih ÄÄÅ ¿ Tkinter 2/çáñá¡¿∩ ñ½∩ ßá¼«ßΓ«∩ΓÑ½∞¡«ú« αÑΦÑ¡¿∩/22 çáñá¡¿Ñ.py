from datetime import datetime
class Person:
    def __init__(self, last_name, birth_date):
        self.last_name = last_name
        self.birth_date = datetime.strptime(birth_date, "%d.%m.%Y").date()
    def get_age(self):
        today = datetime.now().date()
        age = today.year - self.birth_date.year
        if (today.month, today.day) < (self.birth_date.month, self.birth_date.day):
            age -= 1
        return age
    def get_info(self):
        return f"Фамилия: {self.last_name}, Дата рождения: {self.birth_date.strftime('%d.%m.%Y')}, Возраст: {self.get_age()}"
class Applicant(Person):
    def __init__(self, last_name, birth_date, faculty):
        super().__init__(last_name, birth_date)
        self.faculty = faculty
    def get_info(self):
        return f"{super().get_info()}, Факультет: {self.faculty}, Статус: Абитуриент"
class Student(Person):
    def __init__(self, last_name, birth_date, faculty, year):
        super().__init__(last_name, birth_date)
        self.faculty = faculty
        self.year = year
    def get_info(self):
        return f"{super().get_info()}, Факультет: {self.faculty}, Курс: {self.year}, Статус: Студент"
class Teacher(Person):
    def __init__(self, last_name, birth_date, faculty, position, experience):
        super().__init__(last_name, birth_date)
        self.faculty = faculty
        self.position = position
        self.experience = experience
    def get_info(self):
        return f"{super().get_info()}, Факультет: {self.faculty}, Должность: {self.position}, Стаж: {self.experience} лет, Статус: Преподаватель"
def create_persons():
    persons = [
        Applicant("Гладких", "28.04.2007", "Физика"),
        Student("Воскобойников", "14.03.2001", "История", 2),
        Teacher("Орехов", "30.07.1992", "Информатика", "Доцент", 15),
        Applicant("Шахов", "03.08.2006", "Биология"),
        Student("Сорокен", "17.12.2000", "Физика", 3),
        Teacher("Красников", "05.05.1982", "Математика", "Профессор", 25)
    ]
    return persons
def print_all_persons(persons):
    print("\nПолная информация о всех персонах:")
    for person in persons:
        print(person.get_info())
def search_by_age(persons, min_age, max_age):
    print(f"\nПерсоны в возрасте от {min_age} до {max_age} лет:")
    found = False
    for person in persons:
        age = person.get_age()
        if min_age <= age <= max_age:
            print(person.get_info())
if __name__ == "__main__":
    persons = create_persons()
    print_all_persons(persons)
    search_by_age(persons, 18, 25)
    search_by_age(persons, 40, 50)
    