import sqlite3
from datetime import datetime

def add_developer(dev_id, name, joining_date):
    try:
        sqlite_connection = sqlite3.connect('sqlite_python.db')
        cursor = sqlite_connection.cursor()
        print("Подключен к SQLite")


        cursor.execute('''
            CREATE TABLE IF NOT EXISTS new_developers (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                joiningDate TEXT  -- Храним как текст
            );
        ''')


        date_str = str(joining_date)


        cursor.execute('''
            INSERT INTO new_developers (id, name, joiningDate)
            VALUES (?, ?, ?);
        ''', (dev_id, name, date_str))
        
        sqlite_connection.commit()
        print("Разработчик успешно добавлен \n")


        cursor.execute('SELECT name, joiningDate FROM new_developers WHERE id = ?', (dev_id,))
        records = cursor.fetchall()

        for row in records:
            developer = row[0]
            joining_date_str = row[1]
            print(developer, "присоединился", joining_date_str)
            print("Тип даты в БД:", type(joining_date_str))  # Будет str

        cursor.close()

    except sqlite3.Error as error:
        print("Ошибка при работе с SQLite", error)
    finally:
        if sqlite_connection:
            sqlite_connection.close()
            print("Соединение с SQLite закрыто")

# Фиксированная дата: 2020-12-28 10:58:48.828803
fixed_date = datetime(2020, 12, 28, 10, 58, 48, 828803)
add_developer(1, 'Mark', fixed_date)