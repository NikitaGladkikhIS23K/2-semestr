def first_last(letter, st):

    first_index = None
    last_index = None

    for i, char in enumerate(st):
        if char == letter:
            if first_index is None:
                first_index = i
            last_index = i
    
    return (first_index, last_index)

print(first_last('a', 'abacada'))
print(first_last('b', 'abacada'))
print(first_last('x', 'abacada'))
print(first_last('a', 'aaaaa'))
print(first_last('z', ''))
