def main():
    M = int(input("Введите количество строк: "))
    
    spaces_count = []

    for i in range(M):
 
        line = input(f"Введите строку {i + 1}: ")
        
        count_spaces = line.count(' ')
        
        spaces_count.append(count_spaces)

    for i in range(M):
        print(f"Количество пробелов в строке {i + 1}: {spaces_count[i]}")

if __name__ == "__main__":
    main()
