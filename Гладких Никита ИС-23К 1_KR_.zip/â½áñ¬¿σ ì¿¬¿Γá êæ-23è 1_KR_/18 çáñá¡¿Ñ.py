s, s1, s2 = input(), input(), input()
print(s.replace(s1, s2))
