class Student:
    def __init__(self, full_name="", group_number=0, progress=[]):
        self.full_name = full_name
        self.group_number = group_number
        self.progress = progress
    
    def __str__(self):
        txt = f'Студент: {self.full_name} Группа: {self.group_number} Оценки:'
        for x in self.progress:
            txt += f' {str(x)}'
        return txt
    