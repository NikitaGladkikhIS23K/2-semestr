class Phone:
    def __init__(self):
        self.is_on = False
    
    def turn_on(self):
        self.is_on = True
    
    def call(self):
        if self.is_on:
            print('Making call...')

class MobilePhone(Phone):
    def __init__(self):
        super().__init__()
        self.battery = 0
    
    def charge(self, num):
        self.battery = num
        print(f'Charging battery up to... {self.battery}%')
