class PhonePoly:
    def __init__(self):
        self.is_on = False
    
    def info(self):
        print(f'Class name: {PhonePoly.__name__}')
        print(f'If phone is ON: {self.is_on}')

class MobilePhonePoly(PhonePoly):
    def __init__(self):
        super().__init__()
        self.battery = 0
    
    def info(self):
        print(f'Class name: {MobilePhonePoly.__name__}')
        print(f'If mobile phone is ON: {self.is_on}')
        print(f'Battery level: {self.battery}')

def show_polymorphism():
    for item in [PhonePoly, MobilePhonePoly]:
        print('-------')
        obj = item()
        obj.info()

        