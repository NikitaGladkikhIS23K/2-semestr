class Phone:
    @staticmethod
    def model_hash(model):
        if model == 'I785':
            return 34565
        elif model == 'K498':
            return 45567
        else:
            return None
        
def check_sim(self, mobile_operator):
    pass
