class Phone:
    pass
