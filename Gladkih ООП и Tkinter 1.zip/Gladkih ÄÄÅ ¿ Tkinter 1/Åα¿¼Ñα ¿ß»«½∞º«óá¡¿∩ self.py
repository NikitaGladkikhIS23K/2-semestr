class Apple:
    def __init__(self):
        self.whole_amount = 12
    
    def eat(self, number):
        self.whole_amount -= number
        
        