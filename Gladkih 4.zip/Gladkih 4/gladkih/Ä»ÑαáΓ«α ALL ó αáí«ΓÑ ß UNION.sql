SELECT FirstName, LastName
FROM Drimm
UNION ALL SELECT FirstName, LastName
FROM Raaap;
