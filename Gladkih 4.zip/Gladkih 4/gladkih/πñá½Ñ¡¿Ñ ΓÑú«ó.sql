update posts
set tags='{}'
where id=1;
