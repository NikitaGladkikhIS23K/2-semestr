def first_last(letter, st):
    first_index = st.find(letter)
    last_index = st.rfind(letter)

    if first_index == -1:
        return (None, None)
    return (first_index, last_index)

st = 'пример'
letter = 'о'
print(first_last(letter, st))