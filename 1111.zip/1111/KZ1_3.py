import re
def shortener(st):
    cleaned_text = re.sub(r'\([^)]*\)', '', st)
    return cleaned_text

text = 'пример (текста) для кода'
result = shortener(text)
print(result)